#	Python Script Plugin for Noesis
#
#	Reads DDS Textures From .DTX files
#	
#	Author:	Acewell
#	Date:		July 22nd, 2016
#	Source:	https://forum.xentax.com/viewtopic.php?p=120609&sid=ca4f96392b14ec137869e208ab9a1719#p120609
#
#	Changelog:
#	June 19 2020
#		Added additional if statement to catch formats for DXT1 and ARGB32
#		- mariokart64n
#

from inc_noesis import *

def registerNoesisTypes():
	handle = noesis.register("Tron 2.0", ".dtx")
	noesis.setHandlerTypeCheck(handle, Tron2CheckType)
	noesis.setHandlerLoadRGBA(handle, Tron2LoadRGBA)
	#noesis.logPopup()
	return 1

#check if it's this type based on the data
def Tron2CheckType(data):
	bs = NoeBitStream(data)
	bs.seek(0x04, NOESEEK_ABS)
	Magic = bs.readBytes(4)
	print(Magic)
	if Magic != b'\xFB\xFF\xFF\xFF':
		return 0
	return 1
	
def Tron2LoadRGBA(data, texList):
	datasize = len(data) - 0xa4        
	bs = NoeBitStream(data)
	bs.seek(0x08, NOESEEK_ABS)
	imgWidth = bs.readShort()
	imgHeight = bs.readShort()
	bs.seek(0x1A, NOESEEK_ABS)
	texFmt = bs.readUByte()
	bs.seek(0xa4, NOESEEK_ABS)        
	data = bs.readBytes(datasize)     
	
	if texFmt == 3:	#ARGB32
		texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_RGBA32))
	elif texFmt == 4:	#DXT1
		texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_DXT1))
	elif texFmt == 6:	#DXT5
		texList.append(NoeTexture(rapi.getInputName(), imgWidth, imgHeight, data, noesis.NOESISTEX_DXT5))
	
	return 1